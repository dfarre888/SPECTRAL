'use client';
/**
 * Shared UI primitives for the Spectrum Intelligence pages.
 * Small, presentational, Liquid Glass styled.
 */

import React from 'react';
import type { Platform, SpectrumCapability, Side } from '../../lib/spectrum/types';
import { LAYER_COLOR, SIDE_COLOR, capabilityExtent, getAxisConfig, makeLogScale } from '../../lib/spectrum/scale';

/* ---------- GlassCard ---------- */
export function GlassCard({
  children,
  hi,
  style,
  glow,
  ...rest
}: React.HTMLAttributes<HTMLDivElement> & { hi?: boolean; glow?: string }) {
  return (
    <div
      className={hi ? 'sx-glass-hi' : 'sx-glass'}
      style={{ position: 'relative', overflow: 'hidden', ...style }}
      {...rest}
    >
      {glow && (
        <div
          style={{
            position: 'absolute',
            right: -30,
            top: -30,
            width: 120,
            height: 120,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${glow}, transparent 70%)`,
            pointerEvents: 'none',
          }}
        />
      )}
      <div style={{ position: 'relative' }}>{children}</div>
    </div>
  );
}

/* ---------- StatPuck (KPI hero number) ---------- */
export function StatPuck({
  label,
  value,
  unit,
  delta,
  deltaColor,
  glow,
}: {
  label: string;
  value: React.ReactNode;
  unit?: string;
  delta?: string;
  deltaColor?: string;
  glow?: string;
}) {
  return (
    <GlassCard glow={glow} style={{ padding: 20, borderRadius: 18 }}>
      <div className="sx-mono sx-faint" style={{ fontSize: 10, letterSpacing: '0.12em' }}>
        {label}
      </div>
      <div
        className="sx-mono"
        style={{ fontSize: 42, fontWeight: 600, lineHeight: 1.1, marginTop: 8 }}
      >
        {value}
        {unit && <span style={{ fontSize: 18 }}>{unit}</span>}
      </div>
      {delta && (
        <div style={{ fontSize: 11, marginTop: 2, color: deltaColor ?? 'var(--sx-ink-dim)' }}>
          {delta}
        </div>
      )}
    </GlassCard>
  );
}

/* ---------- SideBadge ---------- */
export function SideBadge({ side, group, category }: { side: Side; group?: number | null; category?: string | null }) {
  const color = SIDE_COLOR[side];
  const txt =
    side === 'red'
      ? `RED${group ? ` · GROUP ${group}` : ''}${category ? ` · ${category.toUpperCase()}` : ''}`
      : side === 'blue'
      ? `BLUE${category ? ` · ${category.toUpperCase()}` : ''}`
      : 'NEUTRAL';
  return (
    <span
      className="sx-mono"
      style={{
        fontSize: 10,
        color,
        border: `1px solid ${color}66`,
        padding: '3px 8px',
        borderRadius: 7,
        display: 'inline-block',
      }}
    >
      {txt}
    </span>
  );
}

/* ---------- FootprintStrip (micro spectrum render for library cards) ---------- */
export function FootprintStrip({ platform, height = 20 }: { platform: Platform; height?: number }) {
  const caps = (platform.capabilities ?? []).filter((c) => c.axis === 'rf' || c.axis === 'gnss');
  const W = 240;
  const cfg = getAxisConfig('rf', [4, W - 4]);
  const scale = makeLogScale(cfg.domain, cfg.range);

  if (caps.length === 0) {
    // RF-silent — the teaching signal
    return (
      <div
        style={{
          height,
          borderRadius: 8,
          background: 'rgba(255,255,255,0.03)',
          border: '1px solid var(--sx-glass-line)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <span className="sx-mono sx-faint" style={{ fontSize: 9, letterSpacing: '0.1em' }}>
          — RF SILENT —
        </span>
      </div>
    );
  }

  return (
    <div
      style={{
        position: 'relative',
        height,
        borderRadius: 8,
        background: 'rgba(255,255,255,0.03)',
        border: '1px solid var(--sx-glass-line)',
        overflow: 'hidden',
      }}
    >
      <svg viewBox={`0 0 ${W} ${height}`} preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        {caps.map((c) => {
          const ext = capabilityExtent(c, 'hz');
          if (!ext) return null;
          let x0 = scale(ext[0]);
          let x1 = scale(ext[1]);
          if (x1 < x0) [x0, x1] = [x1, x0];
          const color = platform.side === 'blue' ? SIDE_COLOR.blue : LAYER_COLOR[c.layer];
          return (
            <rect
              key={c.id}
              x={x0}
              y={3}
              width={Math.max(x1 - x0, 3)}
              height={height - 6}
              rx={4}
              fill={color}
              opacity={c.derived ? 0.4 : 0.85}
              strokeDasharray={c.derived ? '3 2' : undefined}
              stroke={c.derived ? color : 'none'}
              strokeWidth={c.derived ? 0.8 : 0}
            />
          );
        })}
      </svg>
    </div>
  );
}

/* ---------- PlatformIcon ---------- */
export function PlatformIcon({ platform, size = 54 }: { platform: Platform; size?: number }) {
  const red = platform.side === 'red';
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.26,
        background: red
          ? 'linear-gradient(135deg,#2a1416,#160a0c)'
          : 'linear-gradient(135deg,#0e2236,#0a1018)',
        border: `1px solid ${red ? 'rgba(248,113,113,0.3)' : 'rgba(74,158,255,0.3)'}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: size * 0.44,
        flexShrink: 0,
      }}
    >
      {platform.icon ?? (red ? '⊹' : '⊺')}
    </div>
  );
}
