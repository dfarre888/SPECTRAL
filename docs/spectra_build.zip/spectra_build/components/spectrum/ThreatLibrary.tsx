'use client';
/**
 * ThreatLibrary — the catalogue (Mockup Frame 02).
 * Red threats and Blue effectors as rich cards, each showing its spectral
 * footprint as a thumbnail. Filter by side and group; click to select.
 */

import React, { useMemo, useState } from 'react';
import type { Platform, Side } from '../../lib/spectrum/types';
import { usePlatforms } from './data';
import { GlassCard, SideBadge, FootprintStrip, PlatformIcon } from '../ui/primitives';

export function ThreatLibrary({
  onOpen,
  onSelect,
  selectedIds = [],
}: {
  onOpen?: (p: Platform) => void;
  onSelect?: (p: Platform) => void;
  selectedIds?: string[];
}) {
  const { platforms } = usePlatforms();
  const [q, setQ] = useState('');
  const [sideFilter, setSideFilter] = useState<Side | 'all'>('all');

  const filtered = useMemo(() => {
    return platforms.filter((p) => {
      if (sideFilter !== 'all' && p.side !== sideFilter) return false;
      if (q && !`${p.name} ${p.origin ?? ''} ${p.category ?? ''}`.toLowerCase().includes(q.toLowerCase()))
        return false;
      return true;
    });
  }, [platforms, q, sideFilter]);

  const redCount = platforms.filter((p) => p.side === 'red').length;
  const blueCount = platforms.filter((p) => p.side === 'blue').length;

  return (
    <div>
      {/* toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <div
          className="sx-glass"
          style={{
            padding: '9px 16px',
            borderRadius: 12,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            flex: '1 1 240px',
            minWidth: 200,
          }}
        >
          <span style={{ color: 'var(--sx-ink-faint)' }}>⌕</span>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search platforms…"
            style={{
              background: 'none',
              border: 'none',
              outline: 'none',
              color: 'var(--sx-ink)',
              fontSize: 12.5,
              fontFamily: 'var(--sx-ui)',
              width: '100%',
            }}
          />
        </div>
        <FilterChip active={sideFilter === 'red'} color="var(--sx-red)" onClick={() => setSideFilter(sideFilter === 'red' ? 'all' : 'red')}>
          ● Red · {redCount}
        </FilterChip>
        <FilterChip active={sideFilter === 'blue'} color="var(--sx-blue)" onClick={() => setSideFilter(sideFilter === 'blue' ? 'all' : 'blue')}>
          ● Blue · {blueCount}
        </FilterChip>
      </div>

      {/* grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: 16,
        }}
      >
        {filtered.map((p) => {
          const isSel = selectedIds.includes(p.id);
          const red = p.side === 'red';
          const tintGlow = red ? 'rgba(248,113,113,0.18)' : 'rgba(74,158,255,0.18)';
          return (
            <GlassCard
              key={p.id}
              hi={isSel}
              style={{
                padding: 0,
                cursor: 'pointer',
                transition: 'transform .15s, box-shadow .15s',
                outline: isSel ? `1px solid ${red ? 'rgba(248,113,113,0.5)' : 'rgba(74,158,255,0.5)'}` : 'none',
              }}
              onClick={() => onSelect?.(p)}
              onDoubleClick={() => onOpen?.(p)}
            >
              {/* header */}
              <div
                style={{
                  height: 118,
                  background: `radial-gradient(110% 130% at 30% 0%, ${tintGlow}, transparent 60%), linear-gradient(160deg, #14181c, #0a0c0e)`,
                  position: 'relative',
                  display: 'flex',
                  alignItems: 'flex-end',
                  padding: 14,
                }}
              >
                <div style={{ position: 'absolute', top: 12, right: 12 }}>
                  <SideBadge side={p.side} group={p.group} category={p.category} />
                </div>
                <PlatformIcon platform={p} />
              </div>
              {/* body */}
              <div style={{ padding: 16 }}>
                <div className="sx-display" style={{ fontWeight: 600, fontSize: 15 }}>
                  {p.name}
                </div>
                <div className="sx-faint" style={{ fontSize: 11, marginTop: 2 }}>
                  {p.origin ?? '—'}
                  {p.variant_label ? ` · ${p.variant_label}` : ''}
                </div>
                <div style={{ marginTop: 13 }}>
                  <FootprintStrip platform={p} />
                </div>
                {/* quick tags */}
                <div style={{ display: 'flex', gap: 6, marginTop: 11, flexWrap: 'wrap' }}>
                  {quickTags(p).map((t) => (
                    <span
                      key={t.text}
                      className="sx-mono"
                      style={{
                        fontSize: 9,
                        padding: '3px 7px',
                        borderRadius: 6,
                        background: `${t.color}1f`,
                        color: t.color,
                      }}
                    >
                      {t.text}
                    </span>
                  ))}
                </div>
              </div>
            </GlassCard>
          );
        })}
      </div>
    </div>
  );
}

function FilterChip({
  children,
  active,
  color,
  onClick,
}: {
  children: React.ReactNode;
  active: boolean;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="sx-glass"
      style={{
        padding: '9px 14px',
        borderRadius: 12,
        fontSize: 12,
        color,
        border: active ? `1px solid ${color}` : '1px solid var(--sx-glass-line)',
        background: active ? `${color}14` : undefined,
        cursor: 'pointer',
      }}
    >
      {children}
    </button>
  );
}

function quickTags(p: Platform): { text: string; color: string }[] {
  const tags: { text: string; color: string }[] = [];
  const caps = p.capabilities ?? [];
  const hasRf = caps.some((c) => (c.axis === 'rf' || c.axis === 'gnss') && ['control', 'video', 'datalink', 'telemetry'].includes(c.fn));
  const silent = caps.some((c) => (c.defeat_resistance ?? []).includes('rf_silent')) || (!hasRf && p.side === 'red');
  const crpa = caps.some((c) => (c.defeat_resistance ?? []).some((r) => r.endsWith('_high')));
  const ir = caps.some((c) => c.axis === 'eo_ir' && c.fn === 'sensor');
  const hpm = caps.some((c) => c.fn === 'hpm');
  const jam = caps.some((c) => c.fn.startsWith('jam_'));
  const detect = caps.some((c) => c.fn.startsWith('detect_'));

  if (silent) tags.push({ text: 'JAM-IMMUNE', color: '#f87171' });
  if (crpa) tags.push({ text: 'CRPA ANTI-JAM', color: '#4ade80' });
  if (ir) tags.push({ text: 'EO/IR', color: '#e879f9' });
  if (hpm) tags.push({ text: 'HPM', color: '#4a9eff' });
  if (jam && !hpm) tags.push({ text: 'RF + GNSS JAM', color: '#4a9eff' });
  if (detect && !jam) tags.push({ text: 'DETECT', color: '#22d3ee' });
  return tags.slice(0, 3);
}
